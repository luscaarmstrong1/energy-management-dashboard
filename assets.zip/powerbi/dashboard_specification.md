# Dashboard Specification

## Page 1: Executive Overview
Cards: Consumo Total, Custo Total, Demanda Máxima, Custo Médio/kWh, Geração Solar, Economia Solar, Emissões Evitadas. Charts: monthly consumption, monthly cost, unit consumption, solar vs consumption, demand by unit.

## Page 2: Consumption Analytics
Load curve, weekday-hour heatmap, consumption by hour, day, sector, unit, peak/off-peak and weekday/weekend.

## Page 3: Demand Management
Demand maximum, contracted demand, utilization, exceedance, demand cost, demand vs contracted, histogram, unit table.

## Page 4: Cost & Tariff
Total cost, energy cost, demand cost, peak/off-peak, exceedance, taxes, average R$/kWh and bill composition.

## Page 5: Solar & Renewables
Installed kWp, generation, self-consumption, export, grid import, avoided energy, financial savings and avoided CO2.

## Page 6: Energy Efficiency
Specific consumption, baseline, actual consumption, deviation, potential savings, investment, payback, opportunity matrix.

## Page 7: Alerts & Anomalies
Alert counts, critical alerts, demand spikes, abnormal consumption, low power factor, solar drop, timeline and operational table.

## Page 8: Unit Detail
Drill-through with unit profile, consumption, demand, cost, tariff, FV, CO2, load factor, intensity, alerts, opportunities and load curve.

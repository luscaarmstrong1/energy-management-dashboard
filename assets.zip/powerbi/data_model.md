# Data Model

Grain:
- `Fato_MedicoesEnergia`: one row per timestamp, unit, and sector.
- `Fato_CustosEnergia`: one row per month and unit.
- `Fato_Oportunidades`: one row per simulated opportunity.
- `Fato_Alertas`: one row per alert event.

Relationships:
- `Dim_Calendario[Data]` 1:N `Fato_MedicoesEnergia[Data]`
- `Dim_Tempo[Hora]` 1:N `Fato_MedicoesEnergia[Hora]`
- `Dim_Unidade[ID_Unidade]` 1:N all fact tables
- `Dim_Setor[ID_Setor]` 1:N `Fato_MedicoesEnergia[ID_Setor]`
- `Dim_Tarifa[ID_Unidade]` 1:1 `Dim_Unidade[ID_Unidade]`

Use single-direction filters from dimensions to facts. Avoid bidirectional relationships unless a specific drill-through behavior requires it.

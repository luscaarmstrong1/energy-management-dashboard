# DAX Measures

## [Consumo Total kWh]

```DAX
Consumo Total kWh =
SUM(Fato_MedicoesEnergia[Consumo_kWh])
```

Unidade/finalidade: medida principal para análise energética e financeira no modelo estrela.

## [Consumo Total MWh]

```DAX
Consumo Total MWh =
DIVIDE([Consumo Total kWh], 1000)
```

Unidade/finalidade: medida principal para análise energética e financeira no modelo estrela.

## [Demanda Maxima kW]

```DAX
Demanda Maxima kW =
MAXX(SUMMARIZE(Fato_MedicoesEnergia, Fato_MedicoesEnergia[Timestamp], Dim_Unidade[ID_Unidade], "DemandaHora", SUM(Fato_MedicoesEnergia[Demanda_kW])), [DemandaHora])
```

Unidade/finalidade: medida principal para análise energética e financeira no modelo estrela.

## [Demanda Contratada kW]

```DAX
Demanda Contratada kW =
MAX(Dim_Tarifa[DemandaContratada_kW])
```

Unidade/finalidade: medida principal para análise energética e financeira no modelo estrela.

## [Excesso de Demanda kW]

```DAX
Excesso de Demanda kW =
MAX(0, [Demanda Maxima kW] - [Demanda Contratada kW])
```

Unidade/finalidade: medida principal para análise energética e financeira no modelo estrela.

## [Utilizacao da Demanda %]

```DAX
Utilizacao da Demanda % =
DIVIDE([Demanda Maxima kW], [Demanda Contratada kW])
```

Unidade/finalidade: medida principal para análise energética e financeira no modelo estrela.

## [Horas Periodo]

```DAX
Horas Periodo =
DISTINCTCOUNT(Fato_MedicoesEnergia[Timestamp])
```

Unidade/finalidade: medida principal para análise energética e financeira no modelo estrela.

## [Fator de Carga]

```DAX
Fator de Carga =
DIVIDE([Consumo Total kWh], [Demanda Maxima kW] * [Horas Periodo])
```

Unidade/finalidade: medida principal para análise energética e financeira no modelo estrela.

## [Custo Total]

```DAX
Custo Total =
SUM(Fato_CustosEnergia[CustoTotal_R])
```

Unidade/finalidade: medida principal para análise energética e financeira no modelo estrela.

## [Custo Medio kWh]

```DAX
Custo Medio kWh =
DIVIDE([Custo Total], [Consumo Total kWh])
```

Unidade/finalidade: medida principal para análise energética e financeira no modelo estrela.

## [Custo Demanda]

```DAX
Custo Demanda =
SUM(Fato_CustosEnergia[CustoDemanda_R])
```

Unidade/finalidade: medida principal para análise energética e financeira no modelo estrela.

## [Custo Energia]

```DAX
Custo Energia =
SUM(Fato_CustosEnergia[CustoEnergia_R])
```

Unidade/finalidade: medida principal para análise energética e financeira no modelo estrela.

## [Custo Ponta]

```DAX
Custo Ponta =
SUM(Fato_CustosEnergia[CustoPonta_R])
```

Unidade/finalidade: medida principal para análise energética e financeira no modelo estrela.

## [Custo Fora Ponta]

```DAX
Custo Fora Ponta =
SUM(Fato_CustosEnergia[CustoForaPonta_R])
```

Unidade/finalidade: medida principal para análise energética e financeira no modelo estrela.

## [Geracao Solar]

```DAX
Geracao Solar =
SUM(Fato_MedicoesEnergia[GeracaoSolar_kWh])
```

Unidade/finalidade: medida principal para análise energética e financeira no modelo estrela.

## [Autoconsumo Solar]

```DAX
Autoconsumo Solar =
SUM(Fato_MedicoesEnergia[AutoconsumoSolar_kWh])
```

Unidade/finalidade: medida principal para análise energética e financeira no modelo estrela.

## [% Energia Solar]

```DAX
% Energia Solar =
DIVIDE([Autoconsumo Solar], [Consumo Total kWh])
```

Unidade/finalidade: medida principal para análise energética e financeira no modelo estrela.

## [Economia Solar]

```DAX
Economia Solar =
SUM(Fato_CustosEnergia[EconomiaSolar_R])
```

Unidade/finalidade: medida principal para análise energética e financeira no modelo estrela.

## [CO2 Evitado]

```DAX
CO2 Evitado =
SUM(Fato_MedicoesEnergia[EmissaoEvitadaSolar_tCO2e])
```

Unidade/finalidade: medida principal para análise energética e financeira no modelo estrela.

## [Importacao Rede]

```DAX
Importacao Rede =
SUM(Fato_MedicoesEnergia[ImportacaoRede_kWh])
```

Unidade/finalidade: medida principal para análise energética e financeira no modelo estrela.

## [Grid Dependency %]

```DAX
Grid Dependency % =
DIVIDE([Importacao Rede], [Consumo Total kWh])
```

Unidade/finalidade: medida principal para análise energética e financeira no modelo estrela.

## [% Variacao Consumo MoM]

```DAX
% Variacao Consumo MoM =
DIVIDE([Consumo Total kWh] - CALCULATE([Consumo Total kWh], DATEADD(Dim_Calendario[Data], -1, MONTH)), CALCULATE([Consumo Total kWh], DATEADD(Dim_Calendario[Data], -1, MONTH)))
```

Unidade/finalidade: medida principal para análise energética e financeira no modelo estrela.

## [% Variacao Custo MoM]

```DAX
% Variacao Custo MoM =
DIVIDE([Custo Total] - CALCULATE([Custo Total], DATEADD(Dim_Calendario[Data], -1, MONTH)), CALCULATE([Custo Total], DATEADD(Dim_Calendario[Data], -1, MONTH)))
```

Unidade/finalidade: medida principal para análise energética e financeira no modelo estrela.

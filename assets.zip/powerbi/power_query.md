# Power Query

1. Importar todos os CSVs da pasta `data/`.
2. Definir tipos: datas como Date, Timestamp como DateTime, métricas como Decimal Number, flags como True/False.
3. Não mesclar fatos entre si no Power Query. Relacionar pelo modelo.
4. Relacionar `Fato_MedicoesEnergia[Data]` com `Dim_Calendario[Data]`.
5. Relacionar `Fato_MedicoesEnergia[Hora]` com `Dim_Tempo[Hora]`.
6. Relacionar fatos a `Dim_Unidade` por `ID_Unidade`.
7. Relacionar `Fato_MedicoesEnergia` a `Dim_Setor` por `ID_Setor`.
8. Relacionar `Fato_CustosEnergia` e `Dim_Tarifa` por `ID_Unidade`.

Example M pattern:

```powerquery
let
    Source = Csv.Document(File.Contents("data/Fato_MedicoesEnergia.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {{"Timestamp", type datetime}, {"Data", type date}, {"Consumo_kWh", type number}})
in
    ChangedTypes
```

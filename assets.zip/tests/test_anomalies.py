from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
fact = pd.read_csv(ROOT / "data" / "Fato_MedicoesEnergia.csv", parse_dates=["Timestamp"])
costs = pd.read_csv(ROOT / "data" / "Fato_CustosEnergia.csv")

def test_alerts_exist():
    alerts = pd.read_csv(ROOT / 'data' / 'Fato_Alertas.csv')
    assert len(alerts) >= 20
    assert {'Alta','Critica','Media'} & set(alerts['Severidade'])

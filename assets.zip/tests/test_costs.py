from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
fact = pd.read_csv(ROOT / "data" / "Fato_MedicoesEnergia.csv", parse_dates=["Timestamp"])
costs = pd.read_csv(ROOT / "data" / "Fato_CustosEnergia.csv")

def test_costs_reconcile():
    parts = costs[['CustoEnergia_R','CustoDemanda_R','CustoUltrapassagem_R','Impostos_R','OutrosCustos_R']].sum(axis=1)
    assert ((parts - costs['CustoTotal_R']).abs() < 1.0).all()

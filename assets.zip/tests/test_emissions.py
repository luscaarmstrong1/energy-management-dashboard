from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
fact = pd.read_csv(ROOT / "data" / "Fato_MedicoesEnergia.csv", parse_dates=["Timestamp"])
costs = pd.read_csv(ROOT / "data" / "Fato_CustosEnergia.csv")

def test_emissions_non_negative():
    assert (fact['Emissao_tCO2e'] >= 0).all()
    assert (fact['EmissaoEvitadaSolar_tCO2e'] >= 0).all()

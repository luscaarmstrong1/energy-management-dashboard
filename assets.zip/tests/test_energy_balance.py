from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
fact = pd.read_csv(ROOT / "data" / "Fato_MedicoesEnergia.csv", parse_dates=["Timestamp"])
costs = pd.read_csv(ROOT / "data" / "Fato_CustosEnergia.csv")

def test_energy_balance():
    consumption_diff = (fact['Consumo_kWh'] - fact['AutoconsumoSolar_kWh'] - fact['ImportacaoRede_kWh']).abs().max()
    generation_diff = (fact['GeracaoSolar_kWh'] - fact['AutoconsumoSolar_kWh'] - fact['ExportacaoRede_kWh']).abs().max()
    assert consumption_diff < 0.01
    assert generation_diff < 0.01

from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
fact = pd.read_csv(ROOT / "data" / "Fato_MedicoesEnergia.csv", parse_dates=["Timestamp"])
costs = pd.read_csv(ROOT / "data" / "Fato_CustosEnergia.csv")

def test_demand_monthly_peak_positive():
    assert (costs['DemandaMaxima_kW'] > 0).all()
    assert (costs['UtilizacaoDemandaPercentual'] > 0).all()

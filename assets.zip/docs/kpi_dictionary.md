# KPI Dictionary

| Nome | Definição | Fórmula | Unidade | Interpretação | Uso gerencial |
| --- | --- | --- | --- | --- | --- |
| Consumo Total | Soma de Consumo_kWh | `SUM(Fato_MedicoesEnergia[Consumo_kWh])` | kWh | Volume total consumido | Apoia priorização e acompanhamento. |
| Demanda Maxima | Maior demanda no periodo | `MAXX(SUMMARIZE(...), [Demanda])` | kW | Pico de potência | Apoia priorização e acompanhamento. |
| Fator de Carga | Energia / (demanda maxima x horas) | `[Consumo Total kWh] / ([Demanda Maxima kW] * [Horas Periodo])` | % | Uso da infraestrutura | Apoia priorização e acompanhamento. |
| Custo Total | Energia + demanda + penalidades + impostos | `SUM(Fato_CustosEnergia[CustoTotal_R])` | R$ | Gasto total | Apoia priorização e acompanhamento. |
| Custo Medio kWh | Custo total dividido por consumo | `[Custo Total] / [Consumo Total kWh]` | R$/kWh | Custo unitário | Apoia priorização e acompanhamento. |
| Solar Coverage | Autoconsumo solar / consumo | `[Autoconsumo Solar] / [Consumo Total kWh]` | % | Cobertura solar | Apoia priorização e acompanhamento. |
| Grid Dependency | Importação da rede / consumo | `[Importacao Rede] / [Consumo Total kWh]` | % | Dependência da rede | Apoia priorização e acompanhamento. |
| CO2 Evitado | Autoconsumo solar x fator de emissão | `SUM(Fato_MedicoesEnergia[EmissaoEvitadaSolar_tCO2e])` | tCO2e | Emissões evitadas | Apoia priorização e acompanhamento. |

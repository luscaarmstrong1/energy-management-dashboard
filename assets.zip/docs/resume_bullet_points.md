# Resume Bullet Points

## Versão curta
- Desenvolvi dashboard de gestão energética com dados horários sintéticos, integrando consumo, demanda, custos, geração fotovoltaica, emissões e oportunidades de eficiência.

## Versão ATS
- Desenvolveu projeto de Business Intelligence em Power BI para Energy Management, utilizando Python, modelo estrela, DAX e Power Query para análise de consumo kWh, demanda kW, tarifas, custos, geração solar, baseline, anomalias e eficiência energética.

## English
- Built an Energy Management Dashboard using synthetic hourly energy data, Python, star-schema modeling, DAX, and Power BI specifications to analyze consumption, demand, cost, solar generation, emissions, anomalies, and energy efficiency opportunities.

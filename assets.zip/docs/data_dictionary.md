# Data Dictionary

| Tabela | Campo | Tipo | Unidade | Descrição | Exemplo |
| --- | --- | --- | --- | --- | --- |
| Fato_MedicoesEnergia | Timestamp | datetime64[us] |  | Campo de Fato_MedicoesEnergia. | 2025-01-01 00:00:00 |
| Fato_MedicoesEnergia | Data | object |  | Campo de Fato_MedicoesEnergia. | 2025-01-01 |
| Fato_MedicoesEnergia | Hora | int64 |  | Campo de Fato_MedicoesEnergia. | 0 |
| Fato_MedicoesEnergia | ID_Unidade | str |  | Campo de Fato_MedicoesEnergia. | U001 |
| Fato_MedicoesEnergia | ID_Setor | str |  | Campo de Fato_MedicoesEnergia. | S001 |
| Fato_MedicoesEnergia | Consumo_kWh | float64 | kWh | Campo de Fato_MedicoesEnergia. | 165.675 |
| Fato_MedicoesEnergia | Demanda_kW | float64 | kW | Campo de Fato_MedicoesEnergia. | 165.675 |
| Fato_MedicoesEnergia | GeracaoSolar_kWh | float64 | kWh | Campo de Fato_MedicoesEnergia. | 0.0 |
| Fato_MedicoesEnergia | ImportacaoRede_kWh | float64 | kWh | Campo de Fato_MedicoesEnergia. | 165.675 |
| Fato_MedicoesEnergia | ExportacaoRede_kWh | float64 | kWh | Campo de Fato_MedicoesEnergia. | 0.0 |
| Fato_MedicoesEnergia | AutoconsumoSolar_kWh | float64 | kWh | Campo de Fato_MedicoesEnergia. | 0.0 |
| Fato_MedicoesEnergia | EnergiaEvitadaRede_kWh | float64 | kWh | Campo de Fato_MedicoesEnergia. | 0.0 |
| Fato_MedicoesEnergia | Temperatura_C | float64 | C | Campo de Fato_MedicoesEnergia. | 21.5 |
| Fato_MedicoesEnergia | DiaUtil | bool |  | Campo de Fato_MedicoesEnergia. | True |
| Fato_MedicoesEnergia | HorarioPonta | bool |  | Campo de Fato_MedicoesEnergia. | False |
| Fato_MedicoesEnergia | FatorPotencia | float64 |  | Campo de Fato_MedicoesEnergia. | 0.9405 |
| Fato_MedicoesEnergia | Tensao_V | float64 | V | Campo de Fato_MedicoesEnergia. | 378.7 |
| Fato_MedicoesEnergia | Corrente_A | float64 | A | Campo de Fato_MedicoesEnergia. | 268.54 |
| Fato_MedicoesEnergia | StatusMedicao | str |  | Campo de Fato_MedicoesEnergia. | Valida |
| Fato_MedicoesEnergia | FatorEmissao_kgCO2_kWh | float64 | kWh | Campo de Fato_MedicoesEnergia. | 0.0385 |
| Fato_MedicoesEnergia | Emissao_kgCO2e | float64 | CO2e | Campo de Fato_MedicoesEnergia. | 6.3785 |
| Fato_MedicoesEnergia | Emissao_tCO2e | float64 | CO2e | Campo de Fato_MedicoesEnergia. | 0.006378 |
| Fato_MedicoesEnergia | EmissaoEvitadaSolar_tCO2e | float64 | CO2e | Campo de Fato_MedicoesEnergia. | 0.0 |
| Fato_MedicoesEnergia | BaselineConsumo_kWh | float64 | kWh | Campo de Fato_MedicoesEnergia. | 280.684 |
| Fato_MedicoesEnergia | DesvioBaseline_kWh | float64 | kWh | Campo de Fato_MedicoesEnergia. | -115.009 |
| Fato_CustosEnergia | MesAno | str |  | Campo de Fato_CustosEnergia. | 2025-01 |
| Fato_CustosEnergia | ID_Unidade | str |  | Campo de Fato_CustosEnergia. | U001 |
| Fato_CustosEnergia | Consumo_kWh | float64 | kWh | Campo de Fato_CustosEnergia. | 609089.75 |
| Fato_CustosEnergia | Consumo_MWh | float64 |  | Campo de Fato_CustosEnergia. | 609.09 |
| Fato_CustosEnergia | ImportacaoRede_kWh | float64 | kWh | Campo de Fato_CustosEnergia. | 509575.14 |
| Fato_CustosEnergia | GeracaoSolar_kWh | float64 | kWh | Campo de Fato_CustosEnergia. | 99748.03 |
| Fato_CustosEnergia | AutoconsumoSolar_kWh | float64 | kWh | Campo de Fato_CustosEnergia. | 99514.61 |
| Fato_CustosEnergia | ExportacaoRede_kWh | float64 | kWh | Campo de Fato_CustosEnergia. | 233.41 |
| Fato_CustosEnergia | DemandaMaxima_kW | float64 | kW | Campo de Fato_CustosEnergia. | 1438.16 |
| Fato_CustosEnergia | DemandaContratada_kW | int64 | kW | Campo de Fato_CustosEnergia. | 1280 |
| Fato_CustosEnergia | DemandaFaturavel_kW | float64 | kW | Campo de Fato_CustosEnergia. | 1438.16 |
| Fato_CustosEnergia | ExcessoDemanda_kW | float64 | kW | Campo de Fato_CustosEnergia. | 158.16 |
| Fato_CustosEnergia | UtilizacaoDemandaPercentual | float64 | % | Campo de Fato_CustosEnergia. | 1.1236 |
| Fato_CustosEnergia | CustoPonta_R | float64 | R$ | Campo de Fato_CustosEnergia. | 113394.03 |
| Fato_CustosEnergia | CustoForaPonta_R | float64 | R$ | Campo de Fato_CustosEnergia. | 266426.52 |
| Fato_CustosEnergia | CustoEnergia_R | float64 | R$ | Campo de Fato_CustosEnergia. | 379820.54 |
| Fato_CustosEnergia | CustoDemanda_R | float64 | R$ | Campo de Fato_CustosEnergia. | 60402.76 |
| Fato_CustosEnergia | CustoUltrapassagem_R | float64 | R$ | Campo de Fato_CustosEnergia. | 13285.52 |
| Fato_CustosEnergia | Impostos_R | float64 | R$ | Campo de Fato_CustosEnergia. | 111109.66 |
| Fato_CustosEnergia | OutrosCustos_R | int64 | R$ | Campo de Fato_CustosEnergia. | 9800 |
| Fato_CustosEnergia | CustoTotal_R | float64 | R$ | Campo de Fato_CustosEnergia. | 574418.49 |
| Fato_CustosEnergia | CustoMedio_R_kWh | float64 | kWh | Campo de Fato_CustosEnergia. | 0.9431 |
| Fato_CustosEnergia | EconomiaSolar_R | float64 | R$ | Campo de Fato_CustosEnergia. | 61699.06 |
| Fato_CustosEnergia | Emissao_tCO2e | float64 | CO2e | Campo de Fato_CustosEnergia. | 19.6186 |
| Fato_CustosEnergia | EmissaoEvitadaSolar_tCO2e | float64 | CO2e | Campo de Fato_CustosEnergia. | 3.8313 |
| Fato_Oportunidades | ID_Oportunidade | str |  | Campo de Fato_Oportunidades. | OPP001 |
| Fato_Oportunidades | ID_Unidade | str |  | Campo de Fato_Oportunidades. | U001 |
| Fato_Oportunidades | Categoria | str |  | Campo de Fato_Oportunidades. | Iluminacao LED |
| Fato_Oportunidades | Descricao | str |  | Campo de Fato_Oportunidades. | Substituir luminarias convencionais por LED i |
| Fato_Oportunidades | Investimento_R | float64 | R$ | Campo de Fato_Oportunidades. | 148962.53 |
| Fato_Oportunidades | Economia_kWh_Ano | float64 | kWh | Campo de Fato_Oportunidades. | 251726.98 |
| Fato_Oportunidades | Economia_R_Ano | float64 | R$ | Campo de Fato_Oportunidades. | 244508.71 |
| Fato_Oportunidades | Payback_Anos | float64 |  | Campo de Fato_Oportunidades. | 0.76 |
| Fato_Oportunidades | Prioridade | str |  | Campo de Fato_Oportunidades. | Alta |
| Fato_Oportunidades | Status | str |  | Campo de Fato_Oportunidades. | Priorizada |
| Fato_Alertas | ID_Alerta | str |  | Campo de Fato_Alertas. | ALT001 |
| Fato_Alertas | Timestamp | datetime64[us] |  | Campo de Fato_Alertas. | 2025-08-19 20:00:00 |
| Fato_Alertas | ID_Unidade | str |  | Campo de Fato_Alertas. | U002 |
| Fato_Alertas | TipoAlerta | str |  | Campo de Fato_Alertas. | Consumo anormal |
| Fato_Alertas | Severidade | str |  | Campo de Fato_Alertas. | Alta |
| Fato_Alertas | ValorMedido | float64 |  | Campo de Fato_Alertas. | 1427.919 |
| Fato_Alertas | ValorEsperado | float64 |  | Campo de Fato_Alertas. | 535.305 |
| Fato_Alertas | DesvioPercentual | float64 | % | Campo de Fato_Alertas. | 1.6675 |
| Fato_Alertas | Status | str |  | Campo de Fato_Alertas. | Aberto |
| Fato_Alertas | Descricao | str |  | Campo de Fato_Alertas. | Consumo anormal identificado por regra estati |
| Dim_Unidade | ID_Unidade | str |  | Campo de Dim_Unidade. | U001 |
| Dim_Unidade | Unidade | str |  | Campo de Dim_Unidade. | Nexus Sao Paulo Manufacturing |
| Dim_Unidade | Cidade | str |  | Campo de Dim_Unidade. | Sao Paulo |
| Dim_Unidade | UF | str |  | Campo de Dim_Unidade. | SP |
| Dim_Unidade | TipoUnidade | str |  | Campo de Dim_Unidade. | Fabrica |
| Dim_Unidade | PerfilOperacao | str |  | Campo de Dim_Unidade. | industrial_shift |
| Dim_Unidade | Area_m2 | int64 |  | Campo de Dim_Unidade. | 18500 |
| Dim_Unidade | Funcionarios | int64 |  | Campo de Dim_Unidade. | 420 |
| Dim_Unidade | PotenciaFV_kWp | int64 | kW | Campo de Dim_Unidade. | 780 |
| Dim_Unidade | DemandaContratada_kW | int64 | kW | Campo de Dim_Unidade. | 1280 |
| Dim_Unidade | TarifaPonta_R_kWh | float64 | kWh | Campo de Dim_Unidade. | 1.42 |
| Dim_Unidade | TarifaForaPonta_R_kWh | float64 | kWh | Campo de Dim_Unidade. | 0.62 |
| Dim_Unidade | TarifaDemanda_R_kW | float64 | kW | Campo de Dim_Unidade. | 42.0 |
| Dim_Unidade | PenalidadeUltrapassagem_R_kW | float64 | kW | Campo de Dim_Unidade. | 84.0 |
| Dim_Unidade | ImpostosPercentual | float64 | % | Campo de Dim_Unidade. | 0.245 |
| Dim_Unidade | OutrosEncargos_R | int64 | R$ | Campo de Dim_Unidade. | 9800 |
| Dim_Unidade | BaseLoad_kW | int64 | kW | Campo de Dim_Unidade. | 210 |
| Dim_Unidade | PeakLoad_kW | int64 | kW | Campo de Dim_Unidade. | 1120 |
| Dim_Unidade | ProductionBase | int64 |  | Campo de Dim_Unidade. | 15500 |
| Dim_Unidade | DemandScenario | str |  | Campo de Dim_Unidade. | adequada |
| Dim_Setor | ID_Setor | str |  | Campo de Dim_Setor. | S001 |
| Dim_Setor | Setor | str |  | Campo de Dim_Setor. | Producao |
| Dim_Setor | TiposUnidadeAplicaveis | str |  | Campo de Dim_Setor. | Fabrica, Unidade industrial leve |
| Dim_Setor | PesoReferencia | float64 |  | Campo de Dim_Setor. | 0.38 |
| Dim_Calendario | Data | object |  | Campo de Dim_Calendario. | 2025-01-01 |
| Dim_Calendario | Ano | int32 |  | Campo de Dim_Calendario. | 2025 |
| Dim_Calendario | Mes | str |  | Campo de Dim_Calendario. | January |
| Dim_Calendario | NumeroMes | int32 |  | Campo de Dim_Calendario. | 1 |
| Dim_Calendario | MesAno | str |  | Campo de Dim_Calendario. | 2025-01 |
| Dim_Calendario | Trimestre | str |  | Campo de Dim_Calendario. | Q1 |
| Dim_Calendario | Semana | int64 |  | Campo de Dim_Calendario. | 1 |
| Dim_Calendario | Dia | int32 |  | Campo de Dim_Calendario. | 1 |
| Dim_Calendario | DiaSemana | int32 |  | Campo de Dim_Calendario. | 2 |
| Dim_Calendario | NomeDiaSemana | str |  | Campo de Dim_Calendario. | Wednesday |
| Dim_Calendario | DiaUtil | bool |  | Campo de Dim_Calendario. | True |
| Dim_Calendario | FimSemana | bool |  | Campo de Dim_Calendario. | False |
| Dim_Calendario | InicioMes | bool |  | Campo de Dim_Calendario. | True |
| Dim_Calendario | FimMes | bool |  | Campo de Dim_Calendario. | False |
| Dim_Tempo | Hora | int64 |  | Campo de Dim_Tempo. | 0 |
| Dim_Tempo | FaixaHoraria | str |  | Campo de Dim_Tempo. | 00:00 |
| Dim_Tempo | Turno | str |  | Campo de Dim_Tempo. | Madrugada |
| Dim_Tempo | Ponta | bool |  | Campo de Dim_Tempo. | False |
| Dim_Tempo | PeriodoDia | str |  | Campo de Dim_Tempo. | Madrugada |
| Dim_Tarifa | ID_Unidade | str |  | Campo de Dim_Tarifa. | U001 |
| Dim_Tarifa | TarifaPonta_R_kWh | float64 | kWh | Campo de Dim_Tarifa. | 1.42 |
| Dim_Tarifa | TarifaForaPonta_R_kWh | float64 | kWh | Campo de Dim_Tarifa. | 0.62 |
| Dim_Tarifa | DemandaContratada_kW | int64 | kW | Campo de Dim_Tarifa. | 1280 |
| Dim_Tarifa | TarifaDemanda_R_kW | float64 | kW | Campo de Dim_Tarifa. | 42.0 |
| Dim_Tarifa | PenalidadeUltrapassagem_R_kW | float64 | kW | Campo de Dim_Tarifa. | 84.0 |
| Dim_Tarifa | ImpostosPercentual | float64 | % | Campo de Dim_Tarifa. | 0.245 |
| Dim_Tarifa | OutrosEncargos_R | int64 | R$ | Campo de Dim_Tarifa. | 9800 |
| Dim_Tarifa | InicioPonta | str |  | Campo de Dim_Tarifa. | 18:00 |
| Dim_Tarifa | FimPonta | str |  | Campo de Dim_Tarifa. | 21:00 |
| Dim_Tarifa | ModeloTarifario | str |  | Campo de Dim_Tarifa. | Time-of-use sintetico parametrizavel |

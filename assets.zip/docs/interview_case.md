# Interview Case

1. The project solves the lack of integrated visibility over energy consumption, demand, cost, solar generation, and efficiency opportunities.
2. Data is structured as a star schema with hourly and monthly fact tables connected to calendar, time, unit, sector, and tariff dimensions.
3. The load curve is generated from operating profiles, base load, peak load, seasonality, temperature, weekday/weekend behavior, and sector weights.
4. Energy is measured in kWh and represents consumption over time. Demand is measured in kW and represents power at a point or interval.
5. Load factor is energy divided by maximum demand times period hours.
6. Contracted demand is analyzed by comparing monthly maximum demand with the contracted value and calculating utilization and exceedance.
7. Energy cost is calculated from imported grid energy split by peak/off-peak tariffs, demand charge, exceedance penalty, taxes, and fixed charges.
8. Peak hours are modeled as configurable parameters, not hardcoded regulation.
9. Solar generation is modeled from installed kWp, daylight, seasonality, temperature loss, and cloud variability.
10. Self-consumption is the portion of solar generation used by the site instead of exported.
11. Solar Coverage equals self-consumed solar energy divided by total consumption.
12. Anomalies are detected with statistical rules such as z-score, rolling mean, and IQR.
13. Baseline is built by historical average by unit, month, and sector.
14. Insights are calculated in `docs/insights.md`.
15. In a real company, the dashboard would support tariff review, demand management, maintenance prioritization, efficiency projects, and executive reporting.

# Executive Summary

## Energy Performance
The synthetic portfolio shows distinct load profiles by industrial, logistics, office, refrigerated, and continuous operations.

## Cost Performance
Cost is driven by imported grid energy, demand charges, taxes, and exceedance penalties.

## Demand Performance
The model intentionally includes adequate, exceeded, and oversized contracted demand scenarios.

## Solar Performance
Solar generation is limited to daylight hours and allocated to autoconsumption and export.

## Efficiency
Baseline deviations, specific consumption, and opportunities identify where action has the highest operational value.

## Risks
Main risks include peak demand exceedance, low power factor events, weekend consumption, and solar underperformance.

## Opportunities
Prioritized measures include demand management, lighting, compressor optimization, variable frequency drives, HVAC controls, and FV expansion.

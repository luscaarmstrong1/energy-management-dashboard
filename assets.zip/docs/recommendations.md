# Executive Recommendations

| Prioridade | Problema identificado | Evidência | Ação sugerida | Impacto esperado |
| --- | --- | --- | --- | --- |
| Alta | Ultrapassagem de demanda em unidades operacionais | Alertas e custos de ultrapassagem concentrados em logística e refrigeração | Revisar demanda contratada e deslocar cargas flexíveis | Redução de penalidades e melhor previsibilidade |
| Alta | Base load elevado em operação contínua | Menor fator de carga e consumo noturno relevante | Investigar cargas permanentes, compressores e utilidades | Redução de consumo fora do horário produtivo |
| Média | Dependência elevada da rede em unidades sem FV | Baixa cobertura solar anual | Avaliar expansão fotovoltaica com estudo técnico-financeiro | Redução de importação, custo e emissões |
| Média | Fator de potência baixo em eventos simulados | Alertas de FP abaixo de referência | Inspecionar banco de capacitores e cargas indutivas | Redução de risco operacional e melhoria elétrica |
| Alta | Oportunidades com payback curto | Carteira anual de economia por unidade | Priorizar LED, demanda, compressores e automação | Captura rápida de economia operacional |

# Insights

1. Nexus Belo Horizonte Metals concentra 42.1% do consumo anual.
2. Nexus Belo Horizonte Metals apresenta o maior custo anual: R$ 24,191,632.
3. Nexus Vitoria Cold Chain tem o maior risco de demanda, com pico 229.9% da demanda contratada.
4. Nexus Curitiba Office mostra baixa utilizacao contratada: 114.7%.
5. Nexus Curitiba Office tem o menor fator de carga anual: 0.36.
6. Nexus Sao Paulo Manufacturing gera a maior economia solar anual: R$ 650,734.
7. A geracao solar evitou 100.0 tCO2e no ano sintetico.
8. Nexus Belo Horizonte Metals possui a maior dependencia da rede: 100.0%.
9. Nexus Belo Horizonte Metals tem o maior potencial financeiro em oportunidades: R$ 2,917,420/ano.
10. Nexus Belo Horizonte Metals concentra o maior numero de alertas operacionais: 14 eventos.

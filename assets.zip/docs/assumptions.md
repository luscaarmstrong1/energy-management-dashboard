# Assumptions

| Premissa | Valor | Unidade | Tipo | Editável | Descrição |
| --- | ---: | --- | --- | --- | --- |
| Período dos dados | 2025 | ano | Synthetic Assumption | Sim | Ano completo em granularidade horária |
| Horário de ponta | 18h-21h | hora | Synthetic Assumption | Sim | Parâmetro usado para separar custo ponta e fora ponta |
| Fator de emissão | 0.0385 | kgCO2e/kWh | Synthetic Assumption | Sim | Valor demonstrativo, não oficial |
| Tarifa energia | por unidade | R$/kWh | Synthetic Assumption | Sim | Valores plausíveis para simulação |
| Demanda contratada | por unidade | kW | Synthetic Assumption | Sim | Criada para cobrir cenários adequado, excedido e superdimensionado |
